MAHINDRA SERVICE — ANDROID APP PROJECT

এই প্রজেক্টে আপনার দেওয়া Mahindra logo, app name, এবং website prototype-টি Android WebView app-এর ভিতরে রাখা হয়েছে। App ইন্টারনেট ছাড়াও HTML screen খুলবে এবং এই prototype-এর localStorage data একই ফোনে থাকবে।

APK বানানোর সহজ উপায়:
1. এই ZIP GitHub-এ নতুন repository-তে upload করুন (সব ফাইলসহ)।
2. GitHub repository > Actions খুলুন।
3. "Build Mahindra Service APK" workflow নির্বাচন করে Run workflow চাপুন।
4. Build শেষ হলে workflow run-এর নিচে Artifacts থেকে "Mahindra-Service-APK" ডাউনলোড করুন।
5. ZIP extract করে app-debug.apk ফোনে নিন; APK tap করে Install দিন। Android চাইলে Settings থেকে ওই source-এর জন্য Install unknown apps অনুমতি দিন।

অথবা Android Studio-তে project folder খুলে Build > Build Bundle(s) / APK(s) > Build APK(s) দিন।

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- এটি আপনার বর্তমান website prototype-কে app shell-এ দেখায়; APK compile করে দেওয়া হয়নি।
- এই version-এ তথ্য শুধু একই ফোনের app storage-এ থাকবে। অন্য ফোনে sync হবে না।
- এটি production secure multi-user app নয়। Admin password frontend HTML-এ রয়েছে; সংবেদনশীল বাস্তব stock/history ব্যবহারের আগে Firebase/backend security version প্রয়োজন।
- Android app package name: com.acimotors.mahindraservice
